let started = !1;
function startCounter() {
    document.querySelectorAll(".counter_line h3").forEach((e) => {
        const t = +e.getAttribute("data-count");
        let o = 0;
        const s = () => {
            o < t &&
                ((o += Math.ceil(t / 50)),
                o > t && (o = t),
                (e.textContent = o + "+"),
                setTimeout(s, 100));
        };
        s();
    });
}
function isInViewport(e) {
    if (!e) return !1;
    const t = e.getBoundingClientRect();
    return t.top < window.innerHeight && t.bottom >= 0;
}
window.addEventListener("scroll", function () {
    const e = document.querySelector(".counter");
    e && !started && isInViewport(e) && (startCounter(), (started = !0));
});
const cards = document.querySelectorAll(".comp_bus_child");
(cards.forEach((e) => {
    e.addEventListener("mouseenter", () => {
        (cards.forEach((e) => e.classList.remove("active")),
            e.classList.add("active"));
    });
}),
    $(document).ready(function () {
        function e(e, t, o, s, n, r) {
            (e.on("init reInit afterChange", function (e, s, n) {
                var r = (n || 0) + 1;
                t.html(r + "/" + s.slideCount);
                var l = (r / s.slideCount) * 100;
                o.css(
                    "background",
                    `conic-gradient(#182653 0deg ${3.6 * l}deg, #CBEBFF ${3.6 * l}deg 360deg)`,
                );
            }),
                e.slick({
                    dots: !1,
                    arrows: !0,
                    infinite: !0,
                    speed: 500,
                    slidesToShow: r,
                    slidesToScroll: 1,
                    autoplay: !0,
                    autoplaySpeed: 2e3,
                    prevArrow: s,
                    nextArrow: n,
                    pauseOnHover: !1,
                    responsive: [
                        {
                            breakpoint: 1025,
                            settings: { slidesToShow: r > 2 ? 2 : r },
                        },
                        { breakpoint: 767, settings: { slidesToShow: 1 } },
                        { breakpoint: 481, settings: { slidesToShow: 1 } },
                    ],
                }));
        }
        (e(
            $(".experts_slider:not([data-slider])"),
            $(".slider1-counter"),
            $(".slider1-progress"),
            $(".slider1-prev"),
            $(".slider1-next"),
            4,
        ),
            e(
                $(".experts_slider5"),
                $(".slider5-counter"),
                $(".slider5-progress"),
                $(".slider5-prev"),
                $(".slider5-next"),
                3,
            ),
            e(
                $(".experts_slider2"),
                $(".slider2-counter"),
                $(".slider2-progress"),
                $(".slider2-prev"),
                $(".slider2-next"),
                3,
            ),
            e(
                $(".experts_slider4"),
                $(".slider4-counter"),
                $(".slider4-progress"),
                $(".slider4-prev"),
                $(".slider4-next"),
                2,
            ),
            e(
                $(".testimonial_slider:not([data-slider])"),
                $(".slider3-counter"),
                $(".slider3-progress"),
                $(".slider3-prev"),
                $(".slider3-next"),
                2,
            ),
            // Generic slider: koi bhi element jisme data-slider ho. Naye sliders ke liye yehi use karo.
            // <div data-slider data-slider-controls="slider5" data-slider-show="3"> + <x-home.slider-controls prefix="slider5" />
            $("[data-slider]").each(function () {
                const el = $(this);
                if (el.hasClass("slick-initialized")) return;
                const p = el.data("slider-controls");
                e(
                    el,
                    $("." + p + "-counter"),
                    $("." + p + "-progress"),
                    $("." + p + "-prev"),
                    $("." + p + "-next"),
                    parseInt(el.data("slider-show"), 10) || 3,
                );
            }));
    }),
    $(".client_slider").slick({
        infinite: !0,
        slidesToShow: 5,
        slidesToScroll: 1,
        dots: !1,
        arrows: !1,
        autoplay: !0,
        autoplaySpeed: 0,
        speed: 5e3,
        cssEase: "linear",
        pauseOnFocus: !1,
        pauseOnHover: !1,
        variableWidth: !0,
    }),
    $(".our_team_slider").slick({
        dots: !1,
        infinite: !0,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: !0,
        fade: !0,
        autoplaySpeed: 3e3,
        prevArrow: $(".team_arrow-prev"),
        nextArrow: $(".team_arrow-next"),
        responsive: [
            { breakpoint: 1024, settings: { slidesToShow: 2 } },
            { breakpoint: 768, settings: { slidesToShow: 1 } },
            { breakpoint: 480, settings: { slidesToShow: 1 } },
        ],
    }));
const buttons = document.querySelectorAll(".bubble-btn");
(buttons.forEach((e) => {
    const t = e.querySelector(".color-button__bubble"),
        o = JSON.parse(e.getAttribute("data-hover-colors"));
    let s = 0;
    (e.addEventListener("mouseenter", (n) => {
        const r = e.getBoundingClientRect(),
            l = n.clientX - r.left,
            i = n.clientY - r.top,
            d = o[s];
        ((s = (s + 1) % o.length),
            (t.style.left = `${l}px`),
            (t.style.top = `${i}px`),
            (t.style.backgroundColor = d),
            (t.style.transform = "translate(-50%, -50%) scale(1.5)"));
    }),
        e.addEventListener("mouseleave", () => {
            t.style.transform = "translate(-50%, -50%) scale(0)";
        }));
}),
    $(".comp_bus_slider").slick({
        dots: !0,
        infinite: !0,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: !0,
        fade: !1,
        autoplaySpeed: 3e3,
        responsive: [{ breakpoint: 768, settings: { slidesToShow: 1 } }],
    }),
    document.addEventListener("DOMContentLoaded", function () {
        const e = document.querySelectorAll(".comp_bus_child");
        e.forEach((t) => {
            t.addEventListener("click", function () {
                (e.forEach((e) => e.classList.remove("active")),
                    this.classList.add("active"));
            });
        });
    }),
    ["1", "2", "3", "4", "5", "6"].forEach((e) => {
        const t = document.getElementById(`service${e}`),
            o = document.getElementById(`service${e}-img`);
        t &&
            o &&
            t.addEventListener("change", () => {
                t.checked
                    ? ((o.style.opacity = "1"), (o.style.display = "block"))
                    : ((o.style.opacity = "0"), (o.style.display = "none"));
            });
    }),
    document.addEventListener("DOMContentLoaded", function () {
        const e = document.querySelector(".load-more-faq"),
            t = document.querySelectorAll(".hidden-faq");
        e.querySelector("svg");
        let o = !1;
        function s() {
            (t.forEach((e, t) => {
                e.style.display = t < 4 ? "block" : "none";
            }),
                (e.querySelector(".color-button__label").textContent =
                    "Load More"),
                e.classList.remove("expanded"));
        }
        (e.addEventListener("click", function (n) {
            (n.preventDefault(),
                (o = !o),
                o
                    ? (t.forEach((e) => {
                          e.style.display = "block";
                      }),
                      (e.querySelector(".color-button__label").textContent =
                          "Show Less"),
                      e.classList.add("expanded"))
                    : s());
        }),
            s());
    }),
    document.addEventListener("DOMContentLoaded", function () {
        const e = document.querySelectorAll(".menu-hover ul li a"),
            t = document.querySelectorAll(".menu-hover-over img");
        let o = 0;
        (gsap.set(t[0], { opacity: 1, y: 0 }),
            e.forEach((e, s) => {
                e.addEventListener("mouseenter", () => {
                    s !== o &&
                        (gsap.to(t[o], {
                            opacity: 0,
                            y: -50,
                            duration: 0.6,
                            ease: "power3.out",
                        }),
                        gsap.fromTo(
                            t[s],
                            { opacity: 0, y: 50 },
                            {
                                opacity: 1,
                                y: 0,
                                duration: 0.8,
                                ease: "power3.out",
                            },
                        ),
                        (o = s));
                });
            }));
    }),
    window.addEventListener("load", function () {
        ((document.getElementById("loader").style.display = "none"),
            (document.getElementById("main-content").style.display = "block"));
    }));
